# -*- coding: utf-8 -*-
"""
Created on Sat May 29 15:09:05 2021

@author: aze14
"""

import lotto

count = lotto.input_count()

lotto.print_lotto(count)
